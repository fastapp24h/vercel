import React from 'react'
import SwapForm from './components/SwapForm'

export default function App() {
  return (
    <div className="p-4 max-w-xl mx-auto">
      <h1 className="text-3xl font-bold mb-4 text-center">Vespa Swap</h1>
      <SwapForm />
    </div>
  )
}
