import React, { useState } from 'react'

export default function SwapForm() {
  const [vespa, setVespa] = useState('')
  const [location, setLocation] = useState('')
  const [description, setDescription] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()
    alert(`Richiesta inviata! Vespa: ${vespa}, Luogo: ${location}`)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 bg-white p-4 rounded shadow">
      <input
        type="text"
        placeholder="Modello Vespa"
        className="w-full p-2 border rounded"
        value={vespa}
        onChange={(e) => setVespa(e.target.value)}
        required
      />
      <input
        type="text"
        placeholder="Luogo"
        className="w-full p-2 border rounded"
        value={location}
        onChange={(e) => setLocation(e.target.value)}
        required
      />
      <textarea
        placeholder="Descrizione"
        className="w-full p-2 border rounded"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
      />
      <button
        type="submit"
        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
      >
        Invia
      </button>
    </form>
  )
}
