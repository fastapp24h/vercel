import React from "react";

export default function App() {
  return (
    <div className="min-h-screen bg-gray-100 text-center p-8">
      <h1 className="text-4xl font-bold mb-4">Scambia la tua Vespa!</h1>
      <p className="text-lg mb-6">Inserisci la tua Vespa e trova uno scambio perfetto.</p>
      <button className="bg-blue-500 text-white px-4 py-2 rounded">Inizia ora</button>
    </div>
  );
}