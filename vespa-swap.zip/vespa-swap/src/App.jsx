import React, { useState } from 'react'

const App = () => {
  const [ads, setAds] = useState([])
  const [input, setInput] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!input.trim()) return
    setAds([...ads, input])
    setInput('')
  }

  return (
    <div className="p-6 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4 text-center">Vespa Swap</h1>
      <form onSubmit={handleSubmit} className="flex gap-2 mb-6">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Inserisci una Vespa da scambiare"
          className="flex-1 px-4 py-2 border rounded"
        />
        <button className="bg-blue-600 text-white px-4 py-2 rounded">Pubblica</button>
      </form>
      <ul className="space-y-2">
        {ads.map((ad, idx) => (
          <li key={idx} className="bg-white shadow p-3 rounded">{ad}</li>
        ))}
      </ul>
    </div>
  )
}

export default App